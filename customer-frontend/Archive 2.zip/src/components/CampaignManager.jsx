import React, { useState, useEffect } from 'react';
import { 
  Plus, Target, TrendingUp, DollarSign, Users, 
  Play, Pause, Edit, BarChart3, AlertCircle,
  Calendar, Globe, Zap, Brain, ChevronRight,
  Search, Eye, ShoppingCart, Download, Video, Heart
} from 'lucide-react';

const CampaignManager = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [showCreateCampaign, setShowCreateCampaign] = useState(false);
  const [campaigns, setCampaigns] = useState([
    {
      id: 1,
      name: 'SaaS Lead Generation Q4 2025',
      platform: 'LinkedIn',
      status: 'Active',
      spend: 456,
      roas: 5.2,
      conversions: 23,
      objective: 'Lead Generation',
      budget: 500,
      startDate: '2025-10-01',
      endDate: 'Ongoing'
    },
    {
      id: 2,
      name: 'App Downloads Campaign',
      platform: 'Meta',
      status: 'Active',
      spend: 234,
      roas: 3.8,
      conversions: 45,
      objective: 'App Downloads',
      budget: 300,
      startDate: '2025-10-05',
      endDate: '2025-11-05'
    },
    {
      id: 3,
      name: 'Brand Awareness Drive',
      platform: 'Google',
      status: 'Paused',
      spend: 123,
      roas: 2.1,
      conversions: 8,
      objective: 'Brand Awareness',
      budget: 200,
      startDate: '2025-09-15',
      endDate: '2025-10-15'
    },
    {
      id: 4,
      name: 'Product Demo Campaign',
      platform: 'Meta',
      status: 'Active',
      spend: 345,
      roas: 4.7,
      conversions: 34,
      objective: 'Video Views',
      budget: 400,
      startDate: '2025-10-10',
      endDate: 'Ongoing'
    }
  ]);

  const [aiRecommendations] = useState([
    {
      id: 1,
      type: 'budget',
      priority: 'high',
      message: 'Increase LinkedIn budget by 15% - predicted +28% lead generation',
      action: 'Increase Budget',
      impact: '+28% leads'
    },
    {
      id: 2,
      type: 'pause',
      priority: 'medium',
      message: 'Pause underperforming Google Ads campaign "Brand Awareness"',
      action: 'Pause Campaign',
      impact: 'Save $77/week'
    },
    {
      id: 3,
      type: 'boost',
      priority: 'high',
      message: 'Boost top organic post from yesterday - 89% viral potential',
      action: 'Boost Post',
      impact: '+340% reach'
    }
  ]);

  const getPlatformIcon = (platform) => {
    switch (platform) {
      case 'Google': return <Search className="w-4 h-4" />;
      case 'Meta': return <Globe className="w-4 h-4" />;
      case 'LinkedIn': return <Users className="w-4 h-4" />;
      default: return <Globe className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active': return 'text-green-600 bg-green-100';
      case 'Paused': return 'text-yellow-600 bg-yellow-100';
      case 'Completed': return 'text-blue-600 bg-blue-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getObjectiveIcon = (objective) => {
    switch (objective) {
      case 'Lead Generation': return <Target className="w-4 h-4" />;
      case 'Brand Awareness': return <Eye className="w-4 h-4" />;
      case 'App Downloads': return <Download className="w-4 h-4" />;
      case 'Video Views': return <Video className="w-4 h-4" />;
      case 'Sales': return <ShoppingCart className="w-4 h-4" />;
      case 'Engagement': return <Heart className="w-4 h-4" />;
      default: return <Target className="w-4 h-4" />;
    }
  };

  const totalSpend = campaigns.reduce((sum, campaign) => sum + campaign.spend, 0);
  const avgRoas = campaigns.reduce((sum, campaign) => sum + campaign.roas, 0) / campaigns.length;
  const totalConversions = campaigns.reduce((sum, campaign) => sum + campaign.conversions, 0);
  const activeCampaigns = campaigns.filter(c => c.status === 'Active').length;

  if (showCreateCampaign) {
    return <CampaignCreationWizard onClose={() => setShowCreateCampaign(false)} />;
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Campaign Manager</h1>
          <p className="text-gray-600">Manage your paid campaigns across all platforms</p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center gap-2 cursor-pointer">
            <Download className="w-4 h-4" />
            Import
          </button>
          <button 
            onClick={() => setShowCreateCampaign(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            New Campaign
          </button>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active Campaigns</p>
              <p className="text-2xl font-bold text-gray-900">{activeCampaigns}</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <Target className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Spend</p>
              <p className="text-2xl font-bold text-gray-900">${totalSpend.toLocaleString()}</p>
              <p className="text-sm text-gray-500">this month</p>
            </div>
            <div className="p-3 bg-green-100 rounded-lg">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg. ROAS</p>
              <p className="text-2xl font-bold text-gray-900">{avgRoas.toFixed(1)}x</p>
              <p className="text-sm text-green-600 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                +12%
              </p>
            </div>
            <div className="p-3 bg-purple-100 rounded-lg">
              <TrendingUp className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Conversions</p>
              <p className="text-2xl font-bold text-gray-900">{totalConversions}</p>
              <p className="text-sm text-green-600 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                +23%
              </p>
            </div>
            <div className="p-3 bg-orange-100 rounded-lg">
              <Users className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      {/* AI Recommendations */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-6 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <Brain className="w-5 h-5 text-blue-600" />
          <h3 className="text-lg font-semibold text-gray-900">AI Recommendations</h3>
        </div>
        <div className="space-y-3">
          {aiRecommendations.map((rec) => (
            <div key={rec.id} className="flex items-center justify-between bg-white p-4 rounded-lg border border-blue-100">
              <div className="flex items-center gap-3">
                <div className={`w-2 h-2 rounded-full ${rec.priority === 'high' ? 'bg-red-500' : 'bg-yellow-500'}`}></div>
                <span className="text-gray-700">{rec.message}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm text-green-600 font-medium">{rec.impact}</span>
                <button className="px-3 py-1 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 cursor-pointer">
                  {rec.action}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Campaign Filters */}
      <div className="flex gap-2 mb-6">
        <button 
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-lg font-medium cursor-pointer ${activeTab === 'overview' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          All Campaigns
        </button>
        <button 
          onClick={() => setActiveTab('google')}
          className={`px-4 py-2 rounded-lg font-medium flex items-center gap-2 cursor-pointer ${activeTab === 'google' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          <Search className="w-4 h-4" />
          Google Ads
        </button>
        <button 
          onClick={() => setActiveTab('meta')}
          className={`px-4 py-2 rounded-lg font-medium flex items-center gap-2 cursor-pointer ${activeTab === 'meta' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          <Globe className="w-4 h-4" />
          Meta Ads
        </button>
        <button 
          onClick={() => setActiveTab('linkedin')}
          className={`px-4 py-2 rounded-lg font-medium flex items-center gap-2 cursor-pointer ${activeTab === 'linkedin' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          <Users className="w-4 h-4" />
          LinkedIn Ads
        </button>
        <button 
          onClick={() => setActiveTab('boosted')}
          className={`px-4 py-2 rounded-lg font-medium cursor-pointer ${activeTab === 'boosted' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          Boosted Posts
        </button>
      </div>

      {/* Campaigns Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Campaign Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Platform
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Spend
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ROAS
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Conversions
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {campaigns.map((campaign) => (
                <tr key={campaign.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-gray-100 rounded-lg">
                        {getObjectiveIcon(campaign.objective)}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">{campaign.name}</div>
                        <div className="text-sm text-gray-500">{campaign.objective}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      {getPlatformIcon(campaign.platform)}
                      <span className="text-sm text-gray-900">{campaign.platform}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(campaign.status)}`}>
                      {campaign.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    ${campaign.spend}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {campaign.roas}x
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {campaign.conversions}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex items-center gap-2">
                      {campaign.status === 'Active' ? (
                        <button 
                          onClick={() => {
                            setCampaigns(prev => prev.map(c => 
                              c.id === campaign.id ? {...c, status: 'Paused'} : c
                            ));
                          }}
                          className="text-yellow-600 hover:text-yellow-900 cursor-pointer"
                          title="Pause Campaign"
                        >
                          <Pause className="w-4 h-4" />
                        </button>
                      ) : (
                        <button 
                          onClick={() => {
                            setCampaigns(prev => prev.map(c => 
                              c.id === campaign.id ? {...c, status: 'Active'} : c
                            ));
                          }}
                          className="text-green-600 hover:text-green-900 cursor-pointer"
                          title="Resume Campaign"
                        >
                          <Play className="w-4 h-4" />
                        </button>
                      )}
                      <button 
                        onClick={() => alert(`Edit campaign: ${campaign.name}`)}
                        className="text-blue-600 hover:text-blue-900 cursor-pointer"
                        title="Edit Campaign"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => alert(`View analytics for: ${campaign.name}`)}
                        className="text-gray-600 hover:text-gray-900 cursor-pointer"
                        title="View Analytics"
                      >
                        <BarChart3 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// Campaign Creation Wizard Component
const CampaignCreationWizard = ({ onClose }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [campaignData, setCampaignData] = useState({
    objective: '',
    platforms: [],
    audience: {},
    budget: {},
    creative: {}
  });

  const objectives = [
    { id: 'lead_generation', name: 'Lead Generation', icon: Target, description: 'Generate qualified leads for your business' },
    { id: 'sales', name: 'Sales & Conversions', icon: ShoppingCart, description: 'Drive sales and conversions' },
    { id: 'brand_awareness', name: 'Brand Awareness', icon: Eye, description: 'Increase brand visibility and recognition' },
    { id: 'app_downloads', name: 'App Downloads', icon: Download, description: 'Promote app installations' },
    { id: 'video_views', name: 'Video Views', icon: Video, description: 'Increase video engagement' },
    { id: 'engagement', name: 'Engagement & Followers', icon: Heart, description: 'Build community and engagement' }
  ];

  const platforms = [
    { id: 'linkedin', name: 'LinkedIn Ads', icon: Users, recommended: true, description: 'Recommended for B2B lead generation' },
    { id: 'meta', name: 'Meta Ads', icon: Globe, recommended: false, description: 'Good for retargeting website visitors' },
    { id: 'google', name: 'Google Ads', icon: Search, recommended: false, description: 'Consider for search intent campaigns' }
  ];

  const handleObjectiveSelect = (objective) => {
    setCampaignData(prev => ({ ...prev, objective }));
  };

  const handlePlatformToggle = (platformId) => {
    setCampaignData(prev => ({
      ...prev,
      platforms: prev.platforms.includes(platformId)
        ? prev.platforms.filter(p => p !== platformId)
        : [...prev.platforms, platformId]
    }));
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">What's your campaign objective?</h3>
        <p className="text-gray-600 mb-6">Choose the primary goal for your campaign</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {objectives.map((obj) => (
          <button
            key={obj.id}
            onClick={() => handleObjectiveSelect(obj.id)}
            className={`p-4 border-2 rounded-lg text-left transition-all cursor-pointer ${
              campaignData.objective === obj.id
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="flex items-center gap-3 mb-2">
              <obj.icon className="w-5 h-5 text-blue-600" />
              <span className="font-medium text-gray-900">{obj.name}</span>
            </div>
            <p className="text-sm text-gray-600">{obj.description}</p>
          </button>
        ))}
      </div>

      {campaignData.objective === 'lead_generation' && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Brain className="w-4 h-4 text-blue-600" />
            <span className="font-medium text-blue-900">AI Recommendation</span>
          </div>
          <p className="text-blue-800 text-sm">
            Based on your SaaS business profile and recent organic performance,
            Lead Generation campaigns typically achieve 4.2x ROAS in your industry.
          </p>
        </div>
      )}

      <div>
        <h4 className="font-medium text-gray-900 mb-4">Which platforms do you want to advertise on?</h4>
        <div className="space-y-3">
          {platforms.map((platform) => (
            <label key={platform.id} className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
              <input
                type="checkbox"
                checked={campaignData.platforms.includes(platform.id)}
                onChange={() => handlePlatformToggle(platform.id)}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              />
              <platform.icon className="w-5 h-5 text-gray-600" />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-gray-900">{platform.name}</span>
                  {platform.recommended && (
                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded">
                      Recommended
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-600">{platform.description}</p>
              </div>
            </label>
          ))}
        </div>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">AI-Generated Audience Recommendations</h3>
        <p className="text-gray-600 mb-6">Based on your organic audience and industry data</p>
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-6">
        <div className="flex items-center gap-2 mb-4">
          <Brain className="w-5 h-5 text-blue-600" />
          <span className="font-medium text-blue-900">AI-Generated Audience Recommendations</span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-white p-4 rounded-lg border border-blue-100">
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-4 h-4 text-blue-600" />
              <span className="font-medium text-gray-900">Primary Audience</span>
            </div>
            <p className="text-sm text-gray-600 mb-2">SaaS Decision Makers</p>
            <p className="text-sm text-gray-600 mb-2">25-45, B2B</p>
            <p className="text-sm text-gray-600 mb-3">1.2M reach</p>
            <button className="w-full px-3 py-1 bg-blue-600 text-white text-sm rounded-lg">
              ✓ Selected
            </button>
          </div>

          <div className="bg-white p-4 rounded-lg border border-gray-200">
            <div className="flex items-center gap-2 mb-2">
              <Users className="w-4 h-4 text-gray-600" />
              <span className="font-medium text-gray-900">Lookalike Audience</span>
            </div>
            <p className="text-sm text-gray-600 mb-2">Similar to your best customers</p>
            <p className="text-sm text-gray-600 mb-2">2.1M reach</p>
            <p className="text-sm text-gray-600 mb-3">94% match</p>
            <button className="w-full px-3 py-1 border border-gray-300 text-gray-700 text-sm rounded-lg hover:bg-gray-50">
              Add
            </button>
          </div>

          <div className="bg-white p-4 rounded-lg border border-gray-200">
            <div className="flex items-center gap-2 mb-2">
              <Globe className="w-4 h-4 text-gray-600" />
              <span className="font-medium text-gray-900">Interest Targeting</span>
            </div>
            <p className="text-sm text-gray-600 mb-2">Business Tools, Productivity</p>
            <p className="text-sm text-gray-600 mb-2">1.8M reach</p>
            <p className="text-sm text-gray-600 mb-3">87% relevance</p>
            <button className="w-full px-3 py-1 border border-gray-300 text-gray-700 text-sm rounded-lg hover:bg-gray-50">
              Add
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h4 className="font-medium text-gray-900 mb-4">Custom Audience Refinement</h4>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Demographics</label>
            <div className="space-y-3">
              <div>
                <label className="block text-sm text-gray-600 mb-1">Age Range</label>
                <div className="flex items-center gap-4">
                  <input type="range" min="18" max="65" defaultValue="25" className="flex-1" />
                  <span className="text-sm text-gray-600">25 - 45</span>
                </div>
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">Location</label>
                <select className="w-full p-2 border border-gray-300 rounded-lg">
                  <option>United States, Canada, UK</option>
                  <option>North America</option>
                  <option>Global</option>
                </select>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Interests & Behaviors</label>
            <div className="grid grid-cols-2 gap-2">
              {['Business Software', 'SaaS Tools', 'Digital Marketing', 'Startup Founders'].map((interest) => (
                <label key={interest} className="flex items-center gap-2">
                  <input type="checkbox" defaultChecked className="w-4 h-4 text-blue-600" />
                  <span className="text-sm text-gray-700">{interest}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">Estimated Audience Size</span>
              <span className="text-sm font-bold text-gray-900">1.2M people</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Estimated Daily Reach</span>
              <span className="text-sm text-gray-900">2,400-6,800 people</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">AI Budget Optimization</h3>
        <p className="text-gray-600 mb-6">Let AI optimize your budget allocation for maximum ROI</p>
      </div>

      <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-lg p-6">
        <div className="flex items-center gap-2 mb-4">
          <Brain className="w-5 h-5 text-green-600" />
          <span className="font-medium text-green-900">AI Budget Recommendations</span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="text-2xl font-bold text-green-900 mb-1">$500/month</div>
            <p className="text-green-800 text-sm mb-4">Recommended Budget</p>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-green-700">Expected Results:</span>
                <span className="text-green-900 font-medium">25-35 leads</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-green-700">Expected ROAS:</span>
                <span className="text-green-900 font-medium">4.2x</span>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium text-green-900 mb-3">Platform Allocation:</h4>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-green-700">LinkedIn: $350 (70%)</span>
                <span className="text-xs text-green-600">Higher conversion rate for B2B</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-green-700">Meta: $150 (30%)</span>
                <span className="text-xs text-green-600">Lower cost, good for retargeting</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h4 className="font-medium text-gray-900 mb-4">Budget Settings</h4>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Campaign Budget</label>
            <div className="flex gap-4">
              <label className="flex items-center gap-2">
                <input type="radio" name="budgetType" className="w-4 h-4 text-blue-600" />
                <span className="text-sm text-gray-700">Daily Budget</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="radio" name="budgetType" defaultChecked className="w-4 h-4 text-blue-600" />
                <span className="text-sm text-gray-700">Monthly Budget</span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Monthly Budget</label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
              <input 
                type="number" 
                defaultValue="500" 
                className="w-full pl-8 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h5 className="font-medium text-gray-900 mb-3">Budget Allocation by Platform</h5>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-medium text-gray-700">LinkedIn Ads</span>
                  <span className="text-sm text-gray-900">70%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full" style={{ width: '70%' }}></div>
                </div>
                <div className="flex justify-between text-xs text-gray-600 mt-1">
                  <span>$350/month</span>
                  <span>Expected: 18-25 leads</span>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-medium text-gray-700">Meta Ads</span>
                  <span className="text-sm text-gray-900">30%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-400 h-2 rounded-full" style={{ width: '30%' }}></div>
                </div>
                <div className="flex justify-between text-xs text-gray-600 mt-1">
                  <span>$150/month</span>
                  <span>Expected: 7-10 leads</span>
                </div>
              </div>
            </div>
            <button className="mt-3 text-sm text-blue-600 hover:text-blue-700">
              Adjust Allocation
            </button>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Bidding Strategy</label>
            <div className="space-y-2">
              <label className="flex items-center gap-2">
                <input type="radio" name="bidding" defaultChecked className="w-4 h-4 text-blue-600" />
                <span className="text-sm text-gray-700">AI-Optimized Bidding (Recommended)</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="radio" name="bidding" className="w-4 h-4 text-blue-600" />
                <span className="text-sm text-gray-700">Manual CPC</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="radio" name="bidding" className="w-4 h-4 text-blue-600" />
                <span className="text-sm text-gray-700">Target CPA: $20</span>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold text-gray-900">Create New Campaign - Step {currentStep} of 5</h2>
              <p className="text-gray-600">Set up your AI-optimized advertising campaign</p>
            </div>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600 cursor-pointer">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          {/* Progress Bar */}
          <div className="mt-4">
            <div className="flex justify-between text-xs text-gray-500 mb-2">
              <span>Objective</span>
              <span>Audience</span>
              <span>Budget</span>
              <span>Creative</span>
              <span>Review</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                style={{ width: `${(currentStep / 5) * 100}%` }}
              ></div>
            </div>
          </div>
        </div>

        <div className="p-6">
          {currentStep === 1 && renderStep1()}
          {currentStep === 2 && renderStep2()}
          {currentStep === 3 && renderStep3()}
          {currentStep === 4 && <div className="text-center py-12 text-gray-500">Creative generation step coming soon...</div>}
          {currentStep === 5 && <div className="text-center py-12 text-gray-500">Review step coming soon...</div>}
        </div>

        <div className="p-6 border-t border-gray-200 flex justify-between">
          <button 
            onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
            disabled={currentStep === 1}
            className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            ← Back
          </button>
          <button 
            onClick={() => setCurrentStep(Math.min(5, currentStep + 1))}
            disabled={currentStep === 5}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 cursor-pointer"
          >
            Continue to {currentStep === 1 ? 'Audience' : currentStep === 2 ? 'Budget' : currentStep === 3 ? 'Creative' : 'Review'} →
          </button>
        </div>
      </div>
    </div>
  );
};

export default CampaignManager;

