import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  BarChart3, 
  Brain, 
  Calendar, 
  Target, 
  Zap, 
  History, 
  TrendingUp, 
  TestTube, 
  DollarSign,
  User,
  Settings as SettingsIcon,
  Sparkles,
  Loader2
} from 'lucide-react'

// Import components
import Dashboard from './components/Dashboard.jsx'
import StrategyPlanner from './components/StrategyPlanner.jsx'
import EnhancedContentCalendar from './components/EnhancedContentCalendar.jsx'
import CampaignManager from './components/CampaignManager.jsx'
import BoostManager from './components/BoostManager.jsx'
import PostHistory from './components/PostHistory.jsx'
import Analytics from './components/PerformanceAnalytics.jsx'
import ABTestingFramework from './components/ABTestingFramework.jsx'
import EnhancedCostOptimizer from './components/EnhancedCostOptimizer.jsx'
import Settings from './components/Settings.jsx'
import Sidebar from './components/Sidebar.jsx'

// Import UI components
import { Card, CardContent } from '@/components/ui/card.jsx'

// Import authentication components
import SignIn from './components/auth/SignIn.jsx'
import SignUp from './components/auth/SignUp.jsx'

// Import enhanced profile component
import ProfileDemo from './ProfileDemo.jsx'

import './App.css'

// Loading Component
const LoadingSpinner = ({ message = "Loading..." }) => (
  <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
    <div className="text-center">
      <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
      <p className="text-gray-600">{message}</p>
    </div>
  </div>
)

// Error Boundary Component
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false, error: null }
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error }
  }

  componentDidCatch(error, errorInfo) {
    console.error('Component error:', error, errorInfo)
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-6 bg-red-50 border border-red-200 rounded-lg m-4">
          <h2 className="text-lg font-semibold text-red-800 mb-2">Component Error</h2>
          <p className="text-red-600 mb-4">This component failed to load. Please try refreshing the page.</p>
          <button 
            onClick={() => window.location.reload()} 
            className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
          >
            Refresh Page
          </button>
          <details className="mt-4">
            <summary className="text-sm text-red-500 cursor-pointer">Error Details</summary>
            <pre className="text-xs text-red-400 mt-1 p-2 bg-red-100 rounded overflow-auto">
              {this.state.error?.toString()}
            </pre>
          </details>
        </div>
      )
    }

    return this.props.children
  }
}

function App() {
  const [currentView, setCurrentView] = useState('dashboard')
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [authView, setAuthView] = useState('signin') // 'signin' or 'signup'
  const [isLoading, setIsLoading] = useState(true)
  const [isAuthenticating, setIsAuthenticating] = useState(false)
  const [user, setUser] = useState({
    name: 'Sarah Johnson',
    email: 'sarah@techstart.com',
    company: 'TechStart Solutions',
    industry: 'SaaS',
    subscription: 'Premium',
    avatar: '/api/placeholder/40/40'
  })

  // Simulated real-time data
  const [dashboardData, setDashboardData] = useState({
    performance: {
      engagement_rate: 4.2,
      reach: 12500,
      followers_growth: 156,
      posts_published: 24
    },
    campaigns: {
      active: 3,
      pending: 2,
      completed: 8,
      total_spend: 2450
    },
    content: {
      scheduled: 12,
      drafts: 8,
      published: 156,
      archived: 23
    },
    ai_insights: {
      optimization_score: 87,
      content_suggestions: 15,
      best_posting_times: ['9:00 AM', '1:00 PM', '6:00 PM'],
      trending_hashtags: ['#AI', '#SocialMedia', '#Marketing', '#Growth']
    },
    cost_analysis: {
      monthly_budget: 5000,
      spent: 2450,
      remaining: 2550,
      cost_per_engagement: 0.45,
      roi: 3.2
    },
    ab_tests: {
      active: 2,
      completed: 5,
      winning_variants: 3,
      improvement_rate: 23.5
    },
    boost_campaigns: {
      active: 4,
      total_boosted: 18,
      avg_performance_lift: 34,
      total_reach_increase: 45000
    },
    tokens: {
      tokensUsed: 2100,
      tokensTotal: 3000
    }
  })

  // Check for existing authentication on app load
  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Simulate loading time
        await new Promise(resolve => setTimeout(resolve, 1000))
        
        const savedAuth = localStorage.getItem('isAuthenticated')
        const savedUser = localStorage.getItem('user')
        
        if (savedAuth === 'true' && savedUser) {
          setIsAuthenticated(true)
          setUser(JSON.parse(savedUser))
        }
      } catch (error) {
        console.error('Error checking authentication:', error)
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [])

  // Update data periodically to simulate real-time updates
  useEffect(() => {
    if (!isAuthenticated) return // Only run when authenticated

    const interval = setInterval(() => {
      setDashboardData(prev => ({
        ...prev,
        performance: {
          ...prev.performance,
          engagement_rate: Math.max(0, prev.performance.engagement_rate + (Math.random() - 0.5) * 0.2),
          reach: Math.max(0, prev.performance.reach + Math.floor((Math.random() - 0.5) * 100)),
          followers_growth: Math.max(0, prev.performance.followers_growth + Math.floor(Math.random() * 3))
        }
      }))
    }, 30000) // Update every 30 seconds

    return () => clearInterval(interval)
  }, [isAuthenticated])

  const handleSignIn = async (userData) => {
    setIsAuthenticating(true)
    try {
      // Simulate authentication delay
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      setUser(userData)
      setIsAuthenticated(true)
      localStorage.setItem('isAuthenticated', 'true')
      localStorage.setItem('user', JSON.stringify(userData))
    } catch (error) {
      console.error('Sign in error:', error)
      alert('Sign in failed. Please try again.')
    } finally {
      setIsAuthenticating(false)
    }
  }

  const handleSignUp = async (userData) => {
    setIsAuthenticating(true)
    try {
      // Simulate authentication delay
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      setUser(userData)
      setIsAuthenticated(true)
      localStorage.setItem('isAuthenticated', 'true')
      localStorage.setItem('user', JSON.stringify(userData))
    } catch (error) {
      console.error('Sign up error:', error)
      alert('Sign up failed. Please try again.')
    } finally {
      setIsAuthenticating(false)
    }
  }

  const handleSignOut = () => {
    setIsAuthenticated(false)
    setUser({})
    localStorage.removeItem('isAuthenticated')
    localStorage.removeItem('user')
    setCurrentView('dashboard')
  }

  const handleUpdateUser = (updatedUser) => {
    setUser(updatedUser)
    localStorage.setItem('user', JSON.stringify(updatedUser))
  }

  // Show loading spinner during initial load
  if (isLoading) {
    return <LoadingSpinner message="Initializing AI Social Media Manager..." />
  }

  // Show authentication loading
  if (isAuthenticating) {
    return <LoadingSpinner message="Authenticating..." />
  }

  // If not authenticated, show auth screens
  if (!isAuthenticated) {
    if (authView === 'signin') {
      return (
        <ErrorBoundary>
          <SignIn 
            onSignIn={handleSignIn}
            onSwitchToSignUp={() => setAuthView('signup')}
          />
        </ErrorBoundary>
      )
    } else {
      return (
        <ErrorBoundary>
          <SignUp 
            onSignUp={handleSignUp}
            onSwitchToSignIn={() => setAuthView('signin')}
          />
        </ErrorBoundary>
      )
    }
  }

  const navigation = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'strategy', label: 'AI Strategy', icon: Brain },
    { id: 'calendar', label: 'Content Calendar', icon: Calendar },
    { id: 'campaigns', label: 'Campaign Manager', icon: Target },
    { id: 'boost', label: 'Boost Manager', icon: Zap },
    { id: 'history', label: 'Post History', icon: History },
    { id: 'analytics', label: 'Analytics', icon: TrendingUp },
    { id: 'testing', label: 'A/B Testing', icon: TestTube },
    { id: 'optimizer', label: 'Cost Optimizer', icon: DollarSign },
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'settings', label: 'Settings', icon: SettingsIcon }
  ]

  const renderCurrentView = () => {
    const viewProps = {
      data: dashboardData,
      user: user,
      onDataUpdate: setDashboardData
    }

    switch (currentView) {
      case 'strategy':
        return (
          <ErrorBoundary>
            <StrategyPlanner {...viewProps} />
          </ErrorBoundary>
        )
      case 'calendar':
        return (
          <ErrorBoundary>
            <EnhancedContentCalendar {...viewProps} />
          </ErrorBoundary>
        )
      case 'campaigns':
        return (
          <ErrorBoundary>
            <CampaignManager {...viewProps} />
          </ErrorBoundary>
        )
      case 'boost':
        return (
          <ErrorBoundary>
            <BoostManager {...viewProps} />
          </ErrorBoundary>
        )
      case 'history':
        return (
          <ErrorBoundary>
            <PostHistory {...viewProps} />
          </ErrorBoundary>
        )
      case 'analytics':
        return (
          <ErrorBoundary>
            <Analytics {...viewProps} />
          </ErrorBoundary>
        )
      case 'testing':
        return (
          <ErrorBoundary>
            <ABTestingFramework {...viewProps} />
          </ErrorBoundary>
        )
      case 'optimizer':
        return (
          <ErrorBoundary>
            <EnhancedCostOptimizer {...viewProps} />
          </ErrorBoundary>
        )
      case 'profile':
        return (
          <ErrorBoundary>
            <ProfileDemo />
          </ErrorBoundary>
        )
      case 'settings':
        return (
          <ErrorBoundary>
            <Settings {...viewProps} />
          </ErrorBoundary>
        )
      default:
        return (
          <ErrorBoundary>
            <Dashboard {...viewProps} />
          </ErrorBoundary>
        )
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
      <div className="flex h-screen">
        {/* Sidebar */}
        <ErrorBoundary>
          <Sidebar 
            navigation={navigation}
            currentView={currentView}
            onViewChange={setCurrentView}
            user={user}
            onSignOut={handleSignOut}
          />
        </ErrorBoundary>

        {/* Enhanced Main Content Area */}
        <main className="flex-1 overflow-hidden relative">
          <div className="h-full overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100 hover:scrollbar-thumb-gray-400">
            <div className="min-h-full pb-20"> {/* Bottom padding to prevent content hiding behind bottom widget */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentView}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="h-full"
                >
                  {renderCurrentView()}
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </main>
      </div>

      {/* Enhanced AI Status Indicator - Moved to bottom right for better UX */}
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.4 }}
        className="fixed bottom-6 right-6 z-50 pointer-events-none"
      >
        <Card className="bg-gradient-to-r from-blue-500 via-purple-500 to-indigo-600 text-white border-0 shadow-xl backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              >
                <Sparkles className="h-5 w-5" />
              </motion.div>
              <div>
                <p className="text-sm font-semibold">AI Active</p>
                <p className="text-xs opacity-90">Optimizing performance</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}

export default App

